"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { useRouter } from "next/navigation";
import { db } from "@/lib/firebase";
import { collection, addDoc, serverTimestamp, query, orderBy, onSnapshot } from "firebase/firestore";

export default function Dashboard() {
  const { user, userData, logOut } = useAuth();
  const router = useRouter();

  // States
  const [title, setTitle] = useState("");
  const [assignTo, setAssignTo] = useState("");
  const [tasks, setTasks] = useState<any[]>([]); // New state to hold our fetched tasks

  const handleLogout = async () => {
    await logOut();
    router.push("/");
  };

  // The "Read" part of CRUD - Fetching tasks live
  useEffect(() => {
    // If there is no user, kick them to the login screen
    if (!user) {
      router.push("/");
      return;
    }

    // Set up a query to get tasks, newest first
    const q = query(collection(db, "tasks"), orderBy("createdAt", "desc"));
    
    // onSnapshot listens to the database live
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const tasksArray = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setTasks(tasksArray);
    });

    return () => unsubscribe(); // Cleanup the listener when you leave the page
  }, [user, router]);

  const handleAddTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !assignTo) return;

    // Safety lock: Don't let the function run if user is missing
    if (!user) {
      alert("You must be logged in!");
      return;
    }

    try {
      await addDoc(collection(db, "tasks"), {
        title: title,
        assignedTo: assignTo,
        status: "pending",
        createdBy: user.email, 
        createdAt: serverTimestamp(),
      });
      setTitle(""); 
      setAssignTo("");
      // Removed the alert because the live update will show the task instantly!
    } catch (error) {
      console.error("Error adding task: ", error);
      alert("Oh no, something went wrong!");
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-xl p-8">
        
        {/* Header Section */}
        <div className="flex justify-between items-center border-b pb-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Workspace</h1>
            <p className="text-gray-500">Logged in as: {userData?.role === 'admin' ? 'ADMIN 👑' : 'TEAMMATE'}</p>
          </div>
          <button onClick={handleLogout} className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition">
            Log Out
          </button>
        </div>

        {/* Task Form */}
        <div className="bg-gray-50 p-6 rounded-lg border mb-8">
          <h2 className="text-xl font-bold mb-4">Assign a New Task</h2>
          <form onSubmit={handleAddTask} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Task Title</label>
              <input 
                type="text" 
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Learn React Native"
                className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Assign To (Email or Name)</label>
              <input 
                type="text" 
                value={assignTo}
                onChange={(e) => setAssignTo(e.target.value)}
                placeholder="e.g. jatin@example.com"
                className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <button type="submit" className="w-full bg-blue-600 text-white font-bold py-2 px-4 rounded hover:bg-blue-700 transition">
              Assign Task
            </button>
          </form>
        </div>

        {/* Task List Section - THIS IS NEW! */}
        <div>
          <h2 className="text-2xl font-bold mb-4 border-b pb-2">Active Tasks</h2>
          {tasks.length === 0 ? (
            <p className="text-gray-500 italic">No tasks assigned yet. You are all caught up!</p>
          ) : (
            <div className="space-y-3">
              {tasks.map((task) => (
                <div key={task.id} className="p-4 bg-white border rounded shadow-sm flex justify-between items-center border-l-4 border-yellow-400">
                  <div>
                    <h3 className="font-bold text-lg">{task.title}</h3>
                    <p className="text-sm text-gray-500">Assigned to: <span className="font-semibold text-gray-700">{task.assignedTo}</span></p>
                  </div>
                  <div>
                    <span className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm font-bold">
                      {task.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
}